// DHCR Auto-Fill — reads building data from window.name
// (set by rent-stabilized-nyc.fly.dev) and fills the search form.
(function () {
  try {
    var d = JSON.parse(window.name);
    if (!d || !d._rsnyc) return;

    // Street type: full name → common abbreviations used by DHCR
    var streetTypeAbbrev = {
      "STREET": ["ST", "STR", "STREET"],
      "AVENUE": ["AVE", "AV", "AVENUE"],
      "ROAD": ["RD", "ROAD"],
      "PLACE": ["PL", "PLACE"],
      "DRIVE": ["DR", "DRIVE"],
      "BOULEVARD": ["BLVD", "BOULEVARD"],
      "COURT": ["CT", "COURT"],
      "LANE": ["LN", "LANE"],
      "WAY": ["WAY"],
      "TERRACE": ["TER", "TERR", "TERRACE"],
      "PLAZA": ["PLZ", "PLAZA"],
      "PARKWAY": ["PKWY", "PKY", "PARKWAY"],
      "CIRCLE": ["CIR", "CIRCLE"],
      "TURNPIKE": ["TPKE", "TURNPIKE"],
      "HIGHWAY": ["HWY", "HIGHWAY"],
      "EXPRESSWAY": ["EXPY", "EXPRESSWAY"],
      "CONCOURSE": ["CONC", "CONCOURSE"],
      "WALK": ["WALK"],
      "LOOP": ["LOOP"],
      "SLIP": ["SLIP"],
      "ALLEY": ["ALY", "ALLEY"],
      "PATH": ["PATH"],
      "SQUARE": ["SQ", "SQUARE"],
      "CRESCENT": ["CRES", "CRESCENT"],
      "ROW": ["ROW"]
    };

    function setField(labelText, value) {
      if (!value) return;
      var labels = document.querySelectorAll("label");
      for (var i = 0; i < labels.length; i++) {
        if (labels[i].textContent.trim().replace(":", "").indexOf(labelText) > -1) {
          var id = labels[i].getAttribute("for");
          if (!id) continue;
          var el = document.getElementById(id);
          if (!el) continue;
          if (el.tagName === "SELECT") {
            selectDropdown(el, value);
          } else {
            el.value = value;
          }
          return;
        }
      }
    }

    function selectDropdown(el, value) {
      var upper = value.toUpperCase().trim();

      // Try exact match first (text or value)
      for (var j = 0; j < el.options.length; j++) {
        var optText = el.options[j].text.toUpperCase().trim();
        var optVal = el.options[j].value.toUpperCase().trim();
        if (optText === upper || optVal === upper) {
          el.selectedIndex = j;
          return;
        }
      }

      // Try abbreviation variants for street types
      var variants = streetTypeAbbrev[upper];
      if (variants) {
        for (var j = 0; j < el.options.length; j++) {
          var optText = el.options[j].text.toUpperCase().trim();
          var optVal = el.options[j].value.toUpperCase().trim();
          for (var k = 0; k < variants.length; k++) {
            if (optText === variants[k] || optVal === variants[k]) {
              el.selectedIndex = j;
              return;
            }
          }
        }
      }

      // Try substring/contains match as last resort
      for (var j = 0; j < el.options.length; j++) {
        var optText = el.options[j].text.toUpperCase().trim();
        if (optText.indexOf(upper) > -1 || upper.indexOf(optText) > -1) {
          el.selectedIndex = j;
          return;
        }
      }
    }

    setField("Street House Number", d.n);
    setField("Street Name", d.s);
    setField("Street Type", d.t);
    setField("County", d.c);
    if (d.dp) setField("Street Direction Prefix", d.dp);

    // Clear data so it doesn't re-fill on refresh
    window.name = "";

    // Success banner
    var banner = document.createElement("div");
    banner.style.cssText =
      "position:fixed;top:0;left:0;right:0;background:#f59e0b;color:#000;text-align:center;padding:10px;z-index:9999;font:bold 14px sans-serif;box-shadow:0 2px 8px rgba(0,0,0,0.3)";
    banner.textContent = "Form auto-filled from NYC Rent Stabilized!";
    document.body.appendChild(banner);
    setTimeout(function () {
      banner.remove();
    }, 4000);
  } catch (e) {
    // No data or invalid JSON — do nothing
  }
})();
